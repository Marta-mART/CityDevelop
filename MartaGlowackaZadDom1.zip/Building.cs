﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.IO;

namespace MartaGlowackaZadDom1
{
    /// <summary>
    /// klasa trzymająca dane budynku
    /// </summary>
    class Building
    {
        //podstawowe dane budynku
        public int price;
        public bool isVisible;
        public String name;

        //umiejetnosci budynku do zwiekszania sukcesów w sektorach
        private int securityBoost;
        private int appearanceBoost;
        private int educationBoost;
        private int communicationBoost;
        private int peopleBoost;
        
        //konstruktor
        public Building(int price = 0, int appearanceBoost =0, int securityBoost =0,  int educationBoost =0, int communicationBoost =0, int peopleBoost=0, String name="brak")
        {
            this.name = name;
            isVisible = false;
            this.price = price;
            this.securityBoost = securityBoost;
            this.appearanceBoost = appearanceBoost;
            this.educationBoost = educationBoost;
            this.communicationBoost = communicationBoost;
            this.peopleBoost = peopleBoost;
         }
        
        /// <summary>
        /// funkcja która sprawia, że budynek wpływa na sektory (np. policja podwyższa bezpieczeństwo)
        /// </summary>                       
        public void Update()
        {
            FormMain.appearanceRate += appearanceBoost;
            FormMain.securityRate += securityBoost;
            FormMain.educationRate += educationBoost;
            FormMain.communicationRate += communicationBoost;
            FormMain.peopleRate += peopleBoost;

         }

        /// <summary>
        /// ustawienie tego, jaki sektor budynek ma wpływać na sektory życia w mieście
        /// </summary>
        public void setBoosts(int appearanceBoost, int securityBoost, int educationBoost, int communicationBoost, int peopleBoost)
        {
            this.securityBoost += securityBoost;
            this.appearanceBoost += appearanceBoost;
            this.educationBoost += educationBoost;
            this.communicationBoost += communicationBoost;
            this.peopleBoost += peopleBoost;
        }



    }
}
