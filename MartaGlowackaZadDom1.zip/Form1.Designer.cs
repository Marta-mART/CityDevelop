﻿namespace MartaGlowackaZadDom1
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.timerMoney = new System.Windows.Forms.Timer(this.components);
            this.textBoxMoney = new System.Windows.Forms.TextBox();
            this.pictureBoxPolice = new System.Windows.Forms.PictureBox();
            this.buttonPolice = new System.Windows.Forms.Button();
            this.labelPolicePrice = new System.Windows.Forms.Label();
            this.pictureBoxPoliceMap = new System.Windows.Forms.PictureBox();
            this.pictureBoxParkMap1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxParkMap2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxParkMap3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxParkMap4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxPark = new System.Windows.Forms.PictureBox();
            this.labelParkPrice = new System.Windows.Forms.Label();
            this.buttonPark = new System.Windows.Forms.Button();
            this.buttonStreet = new System.Windows.Forms.Button();
            this.pictureBoxStreet = new System.Windows.Forms.PictureBox();
            this.labelStreetPrice = new System.Windows.Forms.Label();
            this.pictureBoxStreetMap1 = new System.Windows.Forms.PictureBox();
            this.labelPoliceLevel = new System.Windows.Forms.Label();
            this.labelParkLevel = new System.Windows.Forms.Label();
            this.pictureBoxStreetMap2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap5 = new System.Windows.Forms.PictureBox();
            this.buttonBank = new System.Windows.Forms.Button();
            this.pictureBoxBank = new System.Windows.Forms.PictureBox();
            this.pictureBoxBankMap = new System.Windows.Forms.PictureBox();
            this.labelBankLevel = new System.Windows.Forms.Label();
            this.labelBankPrice = new System.Windows.Forms.Label();
            this.pictureBoxSchool = new System.Windows.Forms.PictureBox();
            this.labelSchoolPrice = new System.Windows.Forms.Label();
            this.buttonSchool = new System.Windows.Forms.Button();
            this.pictureBoxSchoolMap = new System.Windows.Forms.PictureBox();
            this.labelSchoolLevel = new System.Windows.Forms.Label();
            this.pictureBoxStreetMap6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap7 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap8 = new System.Windows.Forms.PictureBox();
            this.buttonAirport = new System.Windows.Forms.Button();
            this.pictureBoxAirport = new System.Windows.Forms.PictureBox();
            this.labelAirportPrice = new System.Windows.Forms.Label();
            this.pictureBoxAirportMap = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap9 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap10 = new System.Windows.Forms.PictureBox();
            this.timerBoost = new System.Windows.Forms.Timer(this.components);
            this.labelAppearance = new System.Windows.Forms.Label();
            this.labelSecurity = new System.Windows.Forms.Label();
            this.labelEducation = new System.Windows.Forms.Label();
            this.labelCommunication = new System.Windows.Forms.Label();
            this.labelPeople = new System.Windows.Forms.Label();
            this.textBoxAppearance = new System.Windows.Forms.TextBox();
            this.textBoxSecurity = new System.Windows.Forms.TextBox();
            this.textBoxEducation = new System.Windows.Forms.TextBox();
            this.textBoxCommunication = new System.Windows.Forms.TextBox();
            this.textBoxPopulation = new System.Windows.Forms.TextBox();
            this.buttonSave = new System.Windows.Forms.Button();
            this.labelInstruction = new System.Windows.Forms.Label();
            this.dataGridViewInfo = new System.Windows.Forms.DataGridView();
            this.labelHistory = new System.Windows.Forms.Label();
            this.pictureBoxHouseMap1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxHouseMap2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxHouseMap3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxHouseMap4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxHouseMap5 = new System.Windows.Forms.PictureBox();
            this.Appearance = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Security = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Education = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Communication = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Population = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cash = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBoxHouseMap6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap11 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap12 = new System.Windows.Forms.PictureBox();
            this.pictureBoxStreetMap13 = new System.Windows.Forms.PictureBox();
            this.pictureBoxHouseMap7 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPolice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPoliceMap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxParkMap1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxParkMap2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxParkMap3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxParkMap4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPark)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBank)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBankMap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSchool)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSchoolMap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAirport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAirportMap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap7)).BeginInit();
            this.SuspendLayout();
            // 
            // timerMoney
            // 
            this.timerMoney.Interval = 700;
            this.timerMoney.Tick += new System.EventHandler(this.timerMoney_Tick);
            // 
            // textBoxMoney
            // 
            this.textBoxMoney.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMoney.Location = new System.Drawing.Point(757, 83);
            this.textBoxMoney.Name = "textBoxMoney";
            this.textBoxMoney.Size = new System.Drawing.Size(100, 22);
            this.textBoxMoney.TabIndex = 0;
            this.textBoxMoney.Text = "0";
            // 
            // pictureBoxPolice
            // 
            this.pictureBoxPolice.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxPolice.Image")));
            this.pictureBoxPolice.InitialImage = null;
            this.pictureBoxPolice.Location = new System.Drawing.Point(19, 214);
            this.pictureBoxPolice.Name = "pictureBoxPolice";
            this.pictureBoxPolice.Size = new System.Drawing.Size(42, 44);
            this.pictureBoxPolice.TabIndex = 2;
            this.pictureBoxPolice.TabStop = false;
            // 
            // buttonPolice
            // 
            this.buttonPolice.Enabled = false;
            this.buttonPolice.Location = new System.Drawing.Point(78, 214);
            this.buttonPolice.Name = "buttonPolice";
            this.buttonPolice.Size = new System.Drawing.Size(122, 44);
            this.buttonPolice.TabIndex = 3;
            this.buttonPolice.Text = "Kup posterunek";
            this.buttonPolice.UseVisualStyleBackColor = true;
            this.buttonPolice.Click += new System.EventHandler(this.buttonPolice_Click);
            // 
            // labelPolicePrice
            // 
            this.labelPolicePrice.AutoSize = true;
            this.labelPolicePrice.Location = new System.Drawing.Point(48, 241);
            this.labelPolicePrice.Name = "labelPolicePrice";
            this.labelPolicePrice.Size = new System.Drawing.Size(24, 17);
            this.labelPolicePrice.TabIndex = 4;
            this.labelPolicePrice.Text = "7$";
            // 
            // pictureBoxPoliceMap
            // 
            this.pictureBoxPoliceMap.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxPoliceMap.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxPoliceMap.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxPoliceMap.Image")));
            this.pictureBoxPoliceMap.InitialImage = null;
            this.pictureBoxPoliceMap.Location = new System.Drawing.Point(441, 254);
            this.pictureBoxPoliceMap.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxPoliceMap.Name = "pictureBoxPoliceMap";
            this.pictureBoxPoliceMap.Size = new System.Drawing.Size(98, 91);
            this.pictureBoxPoliceMap.TabIndex = 5;
            this.pictureBoxPoliceMap.TabStop = false;
            this.pictureBoxPoliceMap.Visible = false;
            // 
            // pictureBoxParkMap1
            // 
            this.pictureBoxParkMap1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxParkMap1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxParkMap1.Image")));
            this.pictureBoxParkMap1.InitialImage = null;
            this.pictureBoxParkMap1.Location = new System.Drawing.Point(674, 254);
            this.pictureBoxParkMap1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxParkMap1.Name = "pictureBoxParkMap1";
            this.pictureBoxParkMap1.Size = new System.Drawing.Size(80, 91);
            this.pictureBoxParkMap1.TabIndex = 6;
            this.pictureBoxParkMap1.TabStop = false;
            this.pictureBoxParkMap1.Visible = false;
            // 
            // pictureBoxParkMap2
            // 
            this.pictureBoxParkMap2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxParkMap2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxParkMap2.Image")));
            this.pictureBoxParkMap2.InitialImage = null;
            this.pictureBoxParkMap2.Location = new System.Drawing.Point(729, 223);
            this.pictureBoxParkMap2.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxParkMap2.Name = "pictureBoxParkMap2";
            this.pictureBoxParkMap2.Size = new System.Drawing.Size(90, 91);
            this.pictureBoxParkMap2.TabIndex = 7;
            this.pictureBoxParkMap2.TabStop = false;
            this.pictureBoxParkMap2.Visible = false;
            // 
            // pictureBoxParkMap3
            // 
            this.pictureBoxParkMap3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxParkMap3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxParkMap3.Image")));
            this.pictureBoxParkMap3.InitialImage = null;
            this.pictureBoxParkMap3.Location = new System.Drawing.Point(742, 300);
            this.pictureBoxParkMap3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxParkMap3.Name = "pictureBoxParkMap3";
            this.pictureBoxParkMap3.Size = new System.Drawing.Size(77, 82);
            this.pictureBoxParkMap3.TabIndex = 8;
            this.pictureBoxParkMap3.TabStop = false;
            this.pictureBoxParkMap3.Visible = false;
            // 
            // pictureBoxParkMap4
            // 
            this.pictureBoxParkMap4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxParkMap4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxParkMap4.Image")));
            this.pictureBoxParkMap4.InitialImage = null;
            this.pictureBoxParkMap4.Location = new System.Drawing.Point(674, 325);
            this.pictureBoxParkMap4.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxParkMap4.Name = "pictureBoxParkMap4";
            this.pictureBoxParkMap4.Size = new System.Drawing.Size(80, 66);
            this.pictureBoxParkMap4.TabIndex = 9;
            this.pictureBoxParkMap4.TabStop = false;
            this.pictureBoxParkMap4.Visible = false;
            // 
            // pictureBoxPark
            // 
            this.pictureBoxPark.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxPark.Image")));
            this.pictureBoxPark.ImageLocation = "";
            this.pictureBoxPark.InitialImage = null;
            this.pictureBoxPark.Location = new System.Drawing.Point(19, 280);
            this.pictureBoxPark.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxPark.Name = "pictureBoxPark";
            this.pictureBoxPark.Size = new System.Drawing.Size(45, 35);
            this.pictureBoxPark.TabIndex = 10;
            this.pictureBoxPark.TabStop = false;
            // 
            // labelParkPrice
            // 
            this.labelParkPrice.AutoSize = true;
            this.labelParkPrice.Location = new System.Drawing.Point(48, 307);
            this.labelParkPrice.Name = "labelParkPrice";
            this.labelParkPrice.Size = new System.Drawing.Size(32, 17);
            this.labelParkPrice.TabIndex = 11;
            this.labelParkPrice.Text = "60$";
            // 
            // buttonPark
            // 
            this.buttonPark.Enabled = false;
            this.buttonPark.Location = new System.Drawing.Point(78, 280);
            this.buttonPark.Name = "buttonPark";
            this.buttonPark.Size = new System.Drawing.Size(122, 44);
            this.buttonPark.TabIndex = 12;
            this.buttonPark.Text = "Kup park";
            this.buttonPark.UseVisualStyleBackColor = true;
            this.buttonPark.Click += new System.EventHandler(this.buttonPark_Click);
            // 
            // buttonStreet
            // 
            this.buttonStreet.Enabled = false;
            this.buttonStreet.Location = new System.Drawing.Point(78, 345);
            this.buttonStreet.Name = "buttonStreet";
            this.buttonStreet.Size = new System.Drawing.Size(122, 44);
            this.buttonStreet.TabIndex = 13;
            this.buttonStreet.Text = "Kup ulicę";
            this.buttonStreet.UseVisualStyleBackColor = true;
            this.buttonStreet.Click += new System.EventHandler(this.buttonStreet_Click);
            // 
            // pictureBoxStreet
            // 
            this.pictureBoxStreet.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreet.Image")));
            this.pictureBoxStreet.ImageLocation = "";
            this.pictureBoxStreet.InitialImage = null;
            this.pictureBoxStreet.Location = new System.Drawing.Point(19, 346);
            this.pictureBoxStreet.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreet.Name = "pictureBoxStreet";
            this.pictureBoxStreet.Size = new System.Drawing.Size(45, 35);
            this.pictureBoxStreet.TabIndex = 14;
            this.pictureBoxStreet.TabStop = false;
            // 
            // labelStreetPrice
            // 
            this.labelStreetPrice.AutoSize = true;
            this.labelStreetPrice.Location = new System.Drawing.Point(40, 381);
            this.labelStreetPrice.Name = "labelStreetPrice";
            this.labelStreetPrice.Size = new System.Drawing.Size(32, 17);
            this.labelStreetPrice.TabIndex = 15;
            this.labelStreetPrice.Text = "10$";
            // 
            // pictureBoxStreetMap1
            // 
            this.pictureBoxStreetMap1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap1.Image")));
            this.pictureBoxStreetMap1.InitialImage = null;
            this.pictureBoxStreetMap1.Location = new System.Drawing.Point(441, 316);
            this.pictureBoxStreetMap1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap1.Name = "pictureBoxStreetMap1";
            this.pictureBoxStreetMap1.Size = new System.Drawing.Size(65, 66);
            this.pictureBoxStreetMap1.TabIndex = 16;
            this.pictureBoxStreetMap1.TabStop = false;
            this.pictureBoxStreetMap1.Visible = false;
            // 
            // labelPoliceLevel
            // 
            this.labelPoliceLevel.AutoSize = true;
            this.labelPoliceLevel.Location = new System.Drawing.Point(448, 228);
            this.labelPoliceLevel.Name = "labelPoliceLevel";
            this.labelPoliceLevel.Size = new System.Drawing.Size(49, 17);
            this.labelPoliceLevel.TabIndex = 17;
            this.labelPoliceLevel.Text = "level 0";
            this.labelPoliceLevel.Visible = false;
            // 
            // labelParkLevel
            // 
            this.labelParkLevel.AutoSize = true;
            this.labelParkLevel.Location = new System.Drawing.Point(677, 228);
            this.labelParkLevel.Name = "labelParkLevel";
            this.labelParkLevel.Size = new System.Drawing.Size(49, 17);
            this.labelParkLevel.TabIndex = 18;
            this.labelParkLevel.Text = "level 0";
            this.labelParkLevel.Visible = false;
            // 
            // pictureBoxStreetMap2
            // 
            this.pictureBoxStreetMap2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap2.Image")));
            this.pictureBoxStreetMap2.InitialImage = null;
            this.pictureBoxStreetMap2.Location = new System.Drawing.Point(441, 374);
            this.pictureBoxStreetMap2.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap2.Name = "pictureBoxStreetMap2";
            this.pictureBoxStreetMap2.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxStreetMap2.TabIndex = 19;
            this.pictureBoxStreetMap2.TabStop = false;
            this.pictureBoxStreetMap2.Visible = false;
            // 
            // pictureBoxStreetMap3
            // 
            this.pictureBoxStreetMap3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap3.Image")));
            this.pictureBoxStreetMap3.InitialImage = null;
            this.pictureBoxStreetMap3.Location = new System.Drawing.Point(491, 380);
            this.pictureBoxStreetMap3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap3.Name = "pictureBoxStreetMap3";
            this.pictureBoxStreetMap3.Size = new System.Drawing.Size(79, 65);
            this.pictureBoxStreetMap3.TabIndex = 20;
            this.pictureBoxStreetMap3.TabStop = false;
            this.pictureBoxStreetMap3.Visible = false;
            // 
            // pictureBoxStreetMap4
            // 
            this.pictureBoxStreetMap4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap4.Image")));
            this.pictureBoxStreetMap4.InitialImage = null;
            this.pictureBoxStreetMap4.Location = new System.Drawing.Point(555, 380);
            this.pictureBoxStreetMap4.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap4.Name = "pictureBoxStreetMap4";
            this.pictureBoxStreetMap4.Size = new System.Drawing.Size(79, 65);
            this.pictureBoxStreetMap4.TabIndex = 21;
            this.pictureBoxStreetMap4.TabStop = false;
            this.pictureBoxStreetMap4.Visible = false;
            // 
            // pictureBoxStreetMap5
            // 
            this.pictureBoxStreetMap5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap5.Image")));
            this.pictureBoxStreetMap5.InitialImage = null;
            this.pictureBoxStreetMap5.Location = new System.Drawing.Point(441, 439);
            this.pictureBoxStreetMap5.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap5.Name = "pictureBoxStreetMap5";
            this.pictureBoxStreetMap5.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxStreetMap5.TabIndex = 22;
            this.pictureBoxStreetMap5.TabStop = false;
            this.pictureBoxStreetMap5.Visible = false;
            // 
            // buttonBank
            // 
            this.buttonBank.Enabled = false;
            this.buttonBank.Location = new System.Drawing.Point(78, 408);
            this.buttonBank.Name = "buttonBank";
            this.buttonBank.Size = new System.Drawing.Size(122, 44);
            this.buttonBank.TabIndex = 23;
            this.buttonBank.Text = "Kup bank";
            this.buttonBank.UseVisualStyleBackColor = true;
            this.buttonBank.Click += new System.EventHandler(this.buttonBank_Click);
            // 
            // pictureBoxBank
            // 
            this.pictureBoxBank.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxBank.Image")));
            this.pictureBoxBank.InitialImage = null;
            this.pictureBoxBank.Location = new System.Drawing.Point(16, 408);
            this.pictureBoxBank.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxBank.Name = "pictureBoxBank";
            this.pictureBoxBank.Size = new System.Drawing.Size(42, 44);
            this.pictureBoxBank.TabIndex = 24;
            this.pictureBoxBank.TabStop = false;
            // 
            // pictureBoxBankMap
            // 
            this.pictureBoxBankMap.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxBankMap.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxBankMap.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxBankMap.Image")));
            this.pictureBoxBankMap.InitialImage = null;
            this.pictureBoxBankMap.Location = new System.Drawing.Point(804, 374);
            this.pictureBoxBankMap.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxBankMap.Name = "pictureBoxBankMap";
            this.pictureBoxBankMap.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxBankMap.TabIndex = 25;
            this.pictureBoxBankMap.TabStop = false;
            this.pictureBoxBankMap.Visible = false;
            // 
            // labelBankLevel
            // 
            this.labelBankLevel.AutoSize = true;
            this.labelBankLevel.Location = new System.Drawing.Point(821, 455);
            this.labelBankLevel.Name = "labelBankLevel";
            this.labelBankLevel.Size = new System.Drawing.Size(49, 17);
            this.labelBankLevel.TabIndex = 26;
            this.labelBankLevel.Text = "level 0";
            this.labelBankLevel.Visible = false;
            // 
            // labelBankPrice
            // 
            this.labelBankPrice.AutoSize = true;
            this.labelBankPrice.Location = new System.Drawing.Point(40, 435);
            this.labelBankPrice.Name = "labelBankPrice";
            this.labelBankPrice.Size = new System.Drawing.Size(32, 17);
            this.labelBankPrice.TabIndex = 27;
            this.labelBankPrice.Text = "42$";
            // 
            // pictureBoxSchool
            // 
            this.pictureBoxSchool.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSchool.Image")));
            this.pictureBoxSchool.InitialImage = null;
            this.pictureBoxSchool.Location = new System.Drawing.Point(16, 467);
            this.pictureBoxSchool.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxSchool.Name = "pictureBoxSchool";
            this.pictureBoxSchool.Size = new System.Drawing.Size(42, 44);
            this.pictureBoxSchool.TabIndex = 28;
            this.pictureBoxSchool.TabStop = false;
            // 
            // labelSchoolPrice
            // 
            this.labelSchoolPrice.AutoSize = true;
            this.labelSchoolPrice.Location = new System.Drawing.Point(40, 494);
            this.labelSchoolPrice.Name = "labelSchoolPrice";
            this.labelSchoolPrice.Size = new System.Drawing.Size(40, 17);
            this.labelSchoolPrice.TabIndex = 29;
            this.labelSchoolPrice.Text = "250$";
            // 
            // buttonSchool
            // 
            this.buttonSchool.Enabled = false;
            this.buttonSchool.Location = new System.Drawing.Point(78, 467);
            this.buttonSchool.Name = "buttonSchool";
            this.buttonSchool.Size = new System.Drawing.Size(122, 44);
            this.buttonSchool.TabIndex = 30;
            this.buttonSchool.Text = "Kup szkołę";
            this.buttonSchool.UseVisualStyleBackColor = true;
            this.buttonSchool.Click += new System.EventHandler(this.buttonSchool_Click);
            // 
            // pictureBoxSchoolMap
            // 
            this.pictureBoxSchoolMap.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxSchoolMap.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxSchoolMap.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxSchoolMap.Image")));
            this.pictureBoxSchoolMap.InitialImage = null;
            this.pictureBoxSchoolMap.Location = new System.Drawing.Point(441, 504);
            this.pictureBoxSchoolMap.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxSchoolMap.Name = "pictureBoxSchoolMap";
            this.pictureBoxSchoolMap.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxSchoolMap.TabIndex = 31;
            this.pictureBoxSchoolMap.TabStop = false;
            this.pictureBoxSchoolMap.Visible = false;
            // 
            // labelSchoolLevel
            // 
            this.labelSchoolLevel.AutoSize = true;
            this.labelSchoolLevel.Location = new System.Drawing.Point(448, 579);
            this.labelSchoolLevel.Name = "labelSchoolLevel";
            this.labelSchoolLevel.Size = new System.Drawing.Size(49, 17);
            this.labelSchoolLevel.TabIndex = 32;
            this.labelSchoolLevel.Text = "level 0";
            this.labelSchoolLevel.Visible = false;
            // 
            // pictureBoxStreetMap6
            // 
            this.pictureBoxStreetMap6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap6.Image")));
            this.pictureBoxStreetMap6.InitialImage = null;
            this.pictureBoxStreetMap6.Location = new System.Drawing.Point(394, 380);
            this.pictureBoxStreetMap6.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap6.Name = "pictureBoxStreetMap6";
            this.pictureBoxStreetMap6.Size = new System.Drawing.Size(63, 65);
            this.pictureBoxStreetMap6.TabIndex = 33;
            this.pictureBoxStreetMap6.TabStop = false;
            this.pictureBoxStreetMap6.Visible = false;
            // 
            // pictureBoxStreetMap7
            // 
            this.pictureBoxStreetMap7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap7.Image")));
            this.pictureBoxStreetMap7.InitialImage = null;
            this.pictureBoxStreetMap7.Location = new System.Drawing.Point(331, 380);
            this.pictureBoxStreetMap7.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap7.Name = "pictureBoxStreetMap7";
            this.pictureBoxStreetMap7.Size = new System.Drawing.Size(63, 65);
            this.pictureBoxStreetMap7.TabIndex = 34;
            this.pictureBoxStreetMap7.TabStop = false;
            this.pictureBoxStreetMap7.Visible = false;
            // 
            // pictureBoxStreetMap8
            // 
            this.pictureBoxStreetMap8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap8.Image")));
            this.pictureBoxStreetMap8.InitialImage = null;
            this.pictureBoxStreetMap8.Location = new System.Drawing.Point(535, 436);
            this.pictureBoxStreetMap8.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap8.Name = "pictureBoxStreetMap8";
            this.pictureBoxStreetMap8.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxStreetMap8.TabIndex = 35;
            this.pictureBoxStreetMap8.TabStop = false;
            this.pictureBoxStreetMap8.Visible = false;
            // 
            // buttonAirport
            // 
            this.buttonAirport.Enabled = false;
            this.buttonAirport.Location = new System.Drawing.Point(78, 528);
            this.buttonAirport.Name = "buttonAirport";
            this.buttonAirport.Size = new System.Drawing.Size(122, 44);
            this.buttonAirport.TabIndex = 36;
            this.buttonAirport.Text = "Kup lotnisko";
            this.buttonAirport.UseVisualStyleBackColor = true;
            this.buttonAirport.Click += new System.EventHandler(this.buttonAirport_Click);
            // 
            // pictureBoxAirport
            // 
            this.pictureBoxAirport.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxAirport.Image")));
            this.pictureBoxAirport.InitialImage = null;
            this.pictureBoxAirport.Location = new System.Drawing.Point(16, 528);
            this.pictureBoxAirport.Name = "pictureBoxAirport";
            this.pictureBoxAirport.Size = new System.Drawing.Size(42, 44);
            this.pictureBoxAirport.TabIndex = 37;
            this.pictureBoxAirport.TabStop = false;
            // 
            // labelAirportPrice
            // 
            this.labelAirportPrice.AutoSize = true;
            this.labelAirportPrice.Location = new System.Drawing.Point(34, 557);
            this.labelAirportPrice.Name = "labelAirportPrice";
            this.labelAirportPrice.Size = new System.Drawing.Size(40, 17);
            this.labelAirportPrice.TabIndex = 38;
            this.labelAirportPrice.Text = "190$";
            // 
            // pictureBoxAirportMap
            // 
            this.pictureBoxAirportMap.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxAirportMap.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxAirportMap.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxAirportMap.Image")));
            this.pictureBoxAirportMap.InitialImage = null;
            this.pictureBoxAirportMap.Location = new System.Drawing.Point(557, 254);
            this.pictureBoxAirportMap.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxAirportMap.Name = "pictureBoxAirportMap";
            this.pictureBoxAirportMap.Size = new System.Drawing.Size(98, 91);
            this.pictureBoxAirportMap.TabIndex = 39;
            this.pictureBoxAirportMap.TabStop = false;
            this.pictureBoxAirportMap.Visible = false;
            // 
            // pictureBoxStreetMap9
            // 
            this.pictureBoxStreetMap9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap9.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap9.Image")));
            this.pictureBoxStreetMap9.InitialImage = null;
            this.pictureBoxStreetMap9.Location = new System.Drawing.Point(344, 329);
            this.pictureBoxStreetMap9.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap9.Name = "pictureBoxStreetMap9";
            this.pictureBoxStreetMap9.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxStreetMap9.TabIndex = 40;
            this.pictureBoxStreetMap9.TabStop = false;
            this.pictureBoxStreetMap9.Visible = false;
            // 
            // pictureBoxStreetMap10
            // 
            this.pictureBoxStreetMap10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap10.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap10.Image")));
            this.pictureBoxStreetMap10.InitialImage = null;
            this.pictureBoxStreetMap10.Location = new System.Drawing.Point(344, 265);
            this.pictureBoxStreetMap10.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap10.Name = "pictureBoxStreetMap10";
            this.pictureBoxStreetMap10.Size = new System.Drawing.Size(65, 65);
            this.pictureBoxStreetMap10.TabIndex = 41;
            this.pictureBoxStreetMap10.TabStop = false;
            this.pictureBoxStreetMap10.Visible = false;
            // 
            // timerBoost
            // 
            this.timerBoost.Interval = 4000;
            this.timerBoost.Tick += new System.EventHandler(this.timerBoost_Tick);
            // 
            // labelAppearance
            // 
            this.labelAppearance.AutoSize = true;
            this.labelAppearance.Location = new System.Drawing.Point(41, 131);
            this.labelAppearance.Name = "labelAppearance";
            this.labelAppearance.Size = new System.Drawing.Size(55, 17);
            this.labelAppearance.TabIndex = 42;
            this.labelAppearance.Text = "Wygląd";
            // 
            // labelSecurity
            // 
            this.labelSecurity.AutoSize = true;
            this.labelSecurity.Location = new System.Drawing.Point(158, 131);
            this.labelSecurity.Name = "labelSecurity";
            this.labelSecurity.Size = new System.Drawing.Size(109, 17);
            this.labelSecurity.TabIndex = 43;
            this.labelSecurity.Text = "Bezpieczeństwo";
            // 
            // labelEducation
            // 
            this.labelEducation.AutoSize = true;
            this.labelEducation.Location = new System.Drawing.Point(334, 131);
            this.labelEducation.Name = "labelEducation";
            this.labelEducation.Size = new System.Drawing.Size(66, 17);
            this.labelEducation.TabIndex = 44;
            this.labelEducation.Text = "Edukacja";
            // 
            // labelCommunication
            // 
            this.labelCommunication.AutoSize = true;
            this.labelCommunication.Location = new System.Drawing.Point(469, 131);
            this.labelCommunication.Name = "labelCommunication";
            this.labelCommunication.Size = new System.Drawing.Size(88, 17);
            this.labelCommunication.TabIndex = 45;
            this.labelCommunication.Text = "Komunikacja";
            // 
            // labelPeople
            // 
            this.labelPeople.AutoSize = true;
            this.labelPeople.Location = new System.Drawing.Point(630, 131);
            this.labelPeople.Name = "labelPeople";
            this.labelPeople.Size = new System.Drawing.Size(70, 17);
            this.labelPeople.TabIndex = 46;
            this.labelPeople.Text = "Populacja";
            // 
            // textBoxAppearance
            // 
            this.textBoxAppearance.BackColor = System.Drawing.Color.PeachPuff;
            this.textBoxAppearance.Location = new System.Drawing.Point(17, 151);
            this.textBoxAppearance.Name = "textBoxAppearance";
            this.textBoxAppearance.Size = new System.Drawing.Size(100, 22);
            this.textBoxAppearance.TabIndex = 47;
            this.textBoxAppearance.Text = "0";
            this.textBoxAppearance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxSecurity
            // 
            this.textBoxSecurity.BackColor = System.Drawing.Color.PeachPuff;
            this.textBoxSecurity.Location = new System.Drawing.Point(164, 151);
            this.textBoxSecurity.Name = "textBoxSecurity";
            this.textBoxSecurity.Size = new System.Drawing.Size(100, 22);
            this.textBoxSecurity.TabIndex = 48;
            this.textBoxSecurity.Text = "0";
            this.textBoxSecurity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxEducation
            // 
            this.textBoxEducation.BackColor = System.Drawing.Color.PeachPuff;
            this.textBoxEducation.Location = new System.Drawing.Point(316, 151);
            this.textBoxEducation.Name = "textBoxEducation";
            this.textBoxEducation.Size = new System.Drawing.Size(100, 22);
            this.textBoxEducation.TabIndex = 49;
            this.textBoxEducation.Text = "0";
            this.textBoxEducation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxCommunication
            // 
            this.textBoxCommunication.BackColor = System.Drawing.Color.PeachPuff;
            this.textBoxCommunication.Location = new System.Drawing.Point(463, 151);
            this.textBoxCommunication.Name = "textBoxCommunication";
            this.textBoxCommunication.Size = new System.Drawing.Size(100, 22);
            this.textBoxCommunication.TabIndex = 50;
            this.textBoxCommunication.Text = "0";
            this.textBoxCommunication.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPopulation
            // 
            this.textBoxPopulation.BackColor = System.Drawing.Color.PeachPuff;
            this.textBoxPopulation.Location = new System.Drawing.Point(616, 151);
            this.textBoxPopulation.Name = "textBoxPopulation";
            this.textBoxPopulation.Size = new System.Drawing.Size(100, 22);
            this.textBoxPopulation.TabIndex = 51;
            this.textBoxPopulation.Text = "0";
            this.textBoxPopulation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonSave
            // 
            this.buttonSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.buttonSave.Location = new System.Drawing.Point(757, 111);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(100, 62);
            this.buttonSave.TabIndex = 52;
            this.buttonSave.Text = "Save this moment to data grid";
            this.buttonSave.UseVisualStyleBackColor = false;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // labelInstruction
            // 
            this.labelInstruction.AutoSize = true;
            this.labelInstruction.Location = new System.Drawing.Point(12, 9);
            this.labelInstruction.MaximumSize = new System.Drawing.Size(0, 30);
            this.labelInstruction.MinimumSize = new System.Drawing.Size(0, 50);
            this.labelInstruction.Name = "labelInstruction";
            this.labelInstruction.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelInstruction.Size = new System.Drawing.Size(786, 50);
            this.labelInstruction.TabIndex = 53;
            this.labelInstruction.Text = resources.GetString("labelInstruction.Text");
            // 
            // dataGridViewInfo
            // 
            this.dataGridViewInfo.AllowUserToAddRows = false;
            this.dataGridViewInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Appearance,
            this.Security,
            this.Education,
            this.Communication,
            this.Population,
            this.Cash});
            this.dataGridViewInfo.Location = new System.Drawing.Point(78, 681);
            this.dataGridViewInfo.Name = "dataGridViewInfo";
            this.dataGridViewInfo.RowTemplate.Height = 24;
            this.dataGridViewInfo.Size = new System.Drawing.Size(752, 135);
            this.dataGridViewInfo.TabIndex = 54;
            // 
            // labelHistory
            // 
            this.labelHistory.AutoSize = true;
            this.labelHistory.Font = new System.Drawing.Font("Papyrus", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHistory.Location = new System.Drawing.Point(384, 646);
            this.labelHistory.Name = "labelHistory";
            this.labelHistory.Size = new System.Drawing.Size(173, 22);
            this.labelHistory.TabIndex = 55;
            this.labelHistory.Text = "TWOJA HISTORIA";
            // 
            // pictureBoxHouseMap1
            // 
            this.pictureBoxHouseMap1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxHouseMap1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxHouseMap1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHouseMap1.Image")));
            this.pictureBoxHouseMap1.InitialImage = null;
            this.pictureBoxHouseMap1.Location = new System.Drawing.Point(535, 499);
            this.pictureBoxHouseMap1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxHouseMap1.Name = "pictureBoxHouseMap1";
            this.pictureBoxHouseMap1.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxHouseMap1.TabIndex = 56;
            this.pictureBoxHouseMap1.TabStop = false;
            this.pictureBoxHouseMap1.Visible = false;
            // 
            // pictureBoxHouseMap2
            // 
            this.pictureBoxHouseMap2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxHouseMap2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxHouseMap2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHouseMap2.Image")));
            this.pictureBoxHouseMap2.InitialImage = null;
            this.pictureBoxHouseMap2.Location = new System.Drawing.Point(251, 377);
            this.pictureBoxHouseMap2.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxHouseMap2.Name = "pictureBoxHouseMap2";
            this.pictureBoxHouseMap2.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxHouseMap2.TabIndex = 57;
            this.pictureBoxHouseMap2.TabStop = false;
            this.pictureBoxHouseMap2.Visible = false;
            // 
            // pictureBoxHouseMap3
            // 
            this.pictureBoxHouseMap3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxHouseMap3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxHouseMap3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHouseMap3.Image")));
            this.pictureBoxHouseMap3.InitialImage = null;
            this.pictureBoxHouseMap3.Location = new System.Drawing.Point(337, 190);
            this.pictureBoxHouseMap3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxHouseMap3.Name = "pictureBoxHouseMap3";
            this.pictureBoxHouseMap3.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxHouseMap3.TabIndex = 58;
            this.pictureBoxHouseMap3.TabStop = false;
            this.pictureBoxHouseMap3.Visible = false;
            // 
            // pictureBoxHouseMap4
            // 
            this.pictureBoxHouseMap4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxHouseMap4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxHouseMap4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHouseMap4.Image")));
            this.pictureBoxHouseMap4.InitialImage = null;
            this.pictureBoxHouseMap4.Location = new System.Drawing.Point(620, 499);
            this.pictureBoxHouseMap4.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxHouseMap4.Name = "pictureBoxHouseMap4";
            this.pictureBoxHouseMap4.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxHouseMap4.TabIndex = 59;
            this.pictureBoxHouseMap4.TabStop = false;
            this.pictureBoxHouseMap4.Visible = false;
            // 
            // pictureBoxHouseMap5
            // 
            this.pictureBoxHouseMap5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxHouseMap5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxHouseMap5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHouseMap5.Image")));
            this.pictureBoxHouseMap5.InitialImage = null;
            this.pictureBoxHouseMap5.Location = new System.Drawing.Point(344, 455);
            this.pictureBoxHouseMap5.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxHouseMap5.Name = "pictureBoxHouseMap5";
            this.pictureBoxHouseMap5.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxHouseMap5.TabIndex = 60;
            this.pictureBoxHouseMap5.TabStop = false;
            this.pictureBoxHouseMap5.Visible = false;
            // 
            // Appearance
            // 
            this.Appearance.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Appearance.HeaderText = "Wygląd";
            this.Appearance.Name = "Appearance";
            // 
            // Security
            // 
            this.Security.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Security.HeaderText = "Bezpieczeństwo";
            this.Security.Name = "Security";
            // 
            // Education
            // 
            this.Education.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Education.HeaderText = "Edukacja";
            this.Education.Name = "Education";
            // 
            // Communication
            // 
            this.Communication.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Communication.HeaderText = "Komunikacja";
            this.Communication.Name = "Communication";
            // 
            // Population
            // 
            this.Population.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Population.HeaderText = "Populacja";
            this.Population.Name = "Population";
            // 
            // Cash
            // 
            this.Cash.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Cash.HeaderText = "Pieniądze";
            this.Cash.MinimumWidth = 50;
            this.Cash.Name = "Cash";
            // 
            // pictureBoxHouseMap6
            // 
            this.pictureBoxHouseMap6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxHouseMap6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxHouseMap6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHouseMap6.Image")));
            this.pictureBoxHouseMap6.InitialImage = null;
            this.pictureBoxHouseMap6.Location = new System.Drawing.Point(709, 499);
            this.pictureBoxHouseMap6.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxHouseMap6.Name = "pictureBoxHouseMap6";
            this.pictureBoxHouseMap6.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxHouseMap6.TabIndex = 61;
            this.pictureBoxHouseMap6.TabStop = false;
            this.pictureBoxHouseMap6.Visible = false;
            // 
            // pictureBoxStreetMap11
            // 
            this.pictureBoxStreetMap11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap11.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap11.Image")));
            this.pictureBoxStreetMap11.InitialImage = null;
            this.pictureBoxStreetMap11.Location = new System.Drawing.Point(616, 380);
            this.pictureBoxStreetMap11.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap11.Name = "pictureBoxStreetMap11";
            this.pictureBoxStreetMap11.Size = new System.Drawing.Size(79, 65);
            this.pictureBoxStreetMap11.TabIndex = 62;
            this.pictureBoxStreetMap11.TabStop = false;
            this.pictureBoxStreetMap11.Visible = false;
            // 
            // pictureBoxStreetMap12
            // 
            this.pictureBoxStreetMap12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap12.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap12.Image")));
            this.pictureBoxStreetMap12.InitialImage = null;
            this.pictureBoxStreetMap12.Location = new System.Drawing.Point(680, 380);
            this.pictureBoxStreetMap12.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap12.Name = "pictureBoxStreetMap12";
            this.pictureBoxStreetMap12.Size = new System.Drawing.Size(79, 65);
            this.pictureBoxStreetMap12.TabIndex = 63;
            this.pictureBoxStreetMap12.TabStop = false;
            this.pictureBoxStreetMap12.Visible = false;
            // 
            // pictureBoxStreetMap13
            // 
            this.pictureBoxStreetMap13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxStreetMap13.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxStreetMap13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxStreetMap13.Image")));
            this.pictureBoxStreetMap13.InitialImage = null;
            this.pictureBoxStreetMap13.Location = new System.Drawing.Point(742, 380);
            this.pictureBoxStreetMap13.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxStreetMap13.Name = "pictureBoxStreetMap13";
            this.pictureBoxStreetMap13.Size = new System.Drawing.Size(79, 65);
            this.pictureBoxStreetMap13.TabIndex = 64;
            this.pictureBoxStreetMap13.TabStop = false;
            this.pictureBoxStreetMap13.Visible = false;
            // 
            // pictureBoxHouseMap7
            // 
            this.pictureBoxHouseMap7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBoxHouseMap7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxHouseMap7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxHouseMap7.Image")));
            this.pictureBoxHouseMap7.InitialImage = null;
            this.pictureBoxHouseMap7.Location = new System.Drawing.Point(251, 280);
            this.pictureBoxHouseMap7.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxHouseMap7.Name = "pictureBoxHouseMap7";
            this.pictureBoxHouseMap7.Size = new System.Drawing.Size(80, 75);
            this.pictureBoxHouseMap7.TabIndex = 65;
            this.pictureBoxHouseMap7.TabStop = false;
            this.pictureBoxHouseMap7.Visible = false;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(882, 853);
            this.Controls.Add(this.pictureBoxHouseMap7);
            this.Controls.Add(this.pictureBoxBankMap);
            this.Controls.Add(this.pictureBoxStreetMap13);
            this.Controls.Add(this.pictureBoxStreetMap12);
            this.Controls.Add(this.pictureBoxStreetMap11);
            this.Controls.Add(this.pictureBoxHouseMap6);
            this.Controls.Add(this.pictureBoxHouseMap5);
            this.Controls.Add(this.pictureBoxHouseMap4);
            this.Controls.Add(this.pictureBoxHouseMap3);
            this.Controls.Add(this.pictureBoxHouseMap2);
            this.Controls.Add(this.pictureBoxHouseMap1);
            this.Controls.Add(this.labelHistory);
            this.Controls.Add(this.dataGridViewInfo);
            this.Controls.Add(this.labelInstruction);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.textBoxPopulation);
            this.Controls.Add(this.textBoxCommunication);
            this.Controls.Add(this.textBoxEducation);
            this.Controls.Add(this.textBoxSecurity);
            this.Controls.Add(this.textBoxAppearance);
            this.Controls.Add(this.labelPeople);
            this.Controls.Add(this.labelCommunication);
            this.Controls.Add(this.labelEducation);
            this.Controls.Add(this.labelSecurity);
            this.Controls.Add(this.labelAppearance);
            this.Controls.Add(this.pictureBoxStreetMap9);
            this.Controls.Add(this.pictureBoxStreetMap10);
            this.Controls.Add(this.pictureBoxAirportMap);
            this.Controls.Add(this.labelAirportPrice);
            this.Controls.Add(this.pictureBoxAirport);
            this.Controls.Add(this.buttonAirport);
            this.Controls.Add(this.pictureBoxStreetMap8);
            this.Controls.Add(this.pictureBoxStreetMap7);
            this.Controls.Add(this.pictureBoxStreetMap6);
            this.Controls.Add(this.labelSchoolLevel);
            this.Controls.Add(this.pictureBoxSchoolMap);
            this.Controls.Add(this.buttonSchool);
            this.Controls.Add(this.labelSchoolPrice);
            this.Controls.Add(this.pictureBoxSchool);
            this.Controls.Add(this.labelBankPrice);
            this.Controls.Add(this.labelBankLevel);
            this.Controls.Add(this.pictureBoxBank);
            this.Controls.Add(this.buttonBank);
            this.Controls.Add(this.pictureBoxStreetMap5);
            this.Controls.Add(this.pictureBoxStreetMap4);
            this.Controls.Add(this.pictureBoxStreetMap3);
            this.Controls.Add(this.pictureBoxStreetMap2);
            this.Controls.Add(this.labelParkLevel);
            this.Controls.Add(this.labelPoliceLevel);
            this.Controls.Add(this.pictureBoxStreetMap1);
            this.Controls.Add(this.labelStreetPrice);
            this.Controls.Add(this.pictureBoxStreet);
            this.Controls.Add(this.buttonStreet);
            this.Controls.Add(this.buttonPark);
            this.Controls.Add(this.labelParkPrice);
            this.Controls.Add(this.pictureBoxPark);
            this.Controls.Add(this.pictureBoxParkMap4);
            this.Controls.Add(this.pictureBoxParkMap3);
            this.Controls.Add(this.pictureBoxParkMap2);
            this.Controls.Add(this.pictureBoxParkMap1);
            this.Controls.Add(this.pictureBoxPoliceMap);
            this.Controls.Add(this.labelPolicePrice);
            this.Controls.Add(this.buttonPolice);
            this.Controls.Add(this.pictureBoxPolice);
            this.Controls.Add(this.textBoxMoney);
            this.MaximumSize = new System.Drawing.Size(900, 900);
            this.MinimumSize = new System.Drawing.Size(900, 900);
            this.Name = "FormMain";
            this.Text = "City Fad";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPolice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPoliceMap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxParkMap1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxParkMap2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxParkMap3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxParkMap4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPark)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBank)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBankMap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSchool)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSchoolMap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAirport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAirportMap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStreetMap13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHouseMap7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timerMoney;
        private System.Windows.Forms.TextBox textBoxMoney;
        private System.Windows.Forms.PictureBox pictureBoxPolice;
        private System.Windows.Forms.Button buttonPolice;
        private System.Windows.Forms.Label labelPolicePrice;
        private System.Windows.Forms.PictureBox pictureBoxPoliceMap;
        private System.Windows.Forms.PictureBox pictureBoxParkMap1;
        private System.Windows.Forms.PictureBox pictureBoxParkMap2;
        private System.Windows.Forms.PictureBox pictureBoxParkMap3;
        private System.Windows.Forms.PictureBox pictureBoxParkMap4;
        private System.Windows.Forms.PictureBox pictureBoxPark;
        private System.Windows.Forms.Label labelParkPrice;
        private System.Windows.Forms.Button buttonPark;
        private System.Windows.Forms.Button buttonStreet;
        private System.Windows.Forms.PictureBox pictureBoxStreet;
        private System.Windows.Forms.Label labelStreetPrice;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap1;
        private System.Windows.Forms.Label labelPoliceLevel;
        private System.Windows.Forms.Label labelParkLevel;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap2;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap3;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap4;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap5;
        private System.Windows.Forms.Button buttonBank;
        private System.Windows.Forms.PictureBox pictureBoxBank;
        private System.Windows.Forms.PictureBox pictureBoxBankMap;
        private System.Windows.Forms.Label labelBankLevel;
        private System.Windows.Forms.Label labelBankPrice;
        private System.Windows.Forms.PictureBox pictureBoxSchool;
        private System.Windows.Forms.Label labelSchoolPrice;
        private System.Windows.Forms.Button buttonSchool;
        private System.Windows.Forms.PictureBox pictureBoxSchoolMap;
        private System.Windows.Forms.Label labelSchoolLevel;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap6;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap7;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap8;
        private System.Windows.Forms.Button buttonAirport;
        private System.Windows.Forms.PictureBox pictureBoxAirport;
        private System.Windows.Forms.Label labelAirportPrice;
        private System.Windows.Forms.PictureBox pictureBoxAirportMap;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap9;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap10;
        private System.Windows.Forms.Timer timerBoost;
        private System.Windows.Forms.Label labelAppearance;
        private System.Windows.Forms.Label labelSecurity;
        private System.Windows.Forms.Label labelEducation;
        private System.Windows.Forms.Label labelCommunication;
        private System.Windows.Forms.Label labelPeople;
        private System.Windows.Forms.TextBox textBoxAppearance;
        private System.Windows.Forms.TextBox textBoxSecurity;
        private System.Windows.Forms.TextBox textBoxEducation;
        private System.Windows.Forms.TextBox textBoxCommunication;
        private System.Windows.Forms.TextBox textBoxPopulation;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Label labelInstruction;
        private System.Windows.Forms.DataGridView dataGridViewInfo;
        private System.Windows.Forms.Label labelHistory;
        private System.Windows.Forms.PictureBox pictureBoxHouseMap1;
        private System.Windows.Forms.PictureBox pictureBoxHouseMap2;
        private System.Windows.Forms.PictureBox pictureBoxHouseMap3;
        private System.Windows.Forms.PictureBox pictureBoxHouseMap4;
        private System.Windows.Forms.PictureBox pictureBoxHouseMap5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Appearance;
        private System.Windows.Forms.DataGridViewTextBoxColumn Security;
        private System.Windows.Forms.DataGridViewTextBoxColumn Education;
        private System.Windows.Forms.DataGridViewTextBoxColumn Communication;
        private System.Windows.Forms.DataGridViewTextBoxColumn Population;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cash;
        private System.Windows.Forms.PictureBox pictureBoxHouseMap6;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap11;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap12;
        private System.Windows.Forms.PictureBox pictureBoxStreetMap13;
        private System.Windows.Forms.PictureBox pictureBoxHouseMap7;
    }
}

