﻿using MartaGlowackaZadDom1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace MartaGlowackaZadDom1
{
    public partial class FormMain : Form
    {
        //początkowa liczba pieniędzy, polecam ustawić na np. 500 do testowania gry
        int money = 100;

        //lista budynków pojawiających się na mapie
        List<Building> buildings = new List<Building>();

        //tablica 13 ulic pojawiających się na mapie
        PictureBox[] tabStreet = new PictureBox[13];

        //początkowe levele budynków
        int policeLevel = 0;
        int bankLevel = 0;
        int parkLevel = 0;
        int schoolLevel = 0;

        //maksymalny level banku, inne levele mogą być nieskończone
        //bank sprawia, że pieniądze produkują się szybciej
        int maxBankLevel = 3;

        //początkowe ustawienia sukcesów
        public static int appearanceRate = 0;
        public static int securityRate = 0;
        public static int educationRate = 0;
        public static int communicationRate = 0;
        public static int peopleRate = 0;

        //Dodatkowe, pojednycze wydarzenie - apokalipsa
        bool wasApocalipse = false;

        public FormMain()
        {
            InitializeComponent();

            ///zalaczenie timera generującego pieniądze
            timerMoney.Start();
            ///zalaczenie timera aktualizującego sukcesy
            timerBoost.Start();

            //wkładamy w tablicę ulic obrazki ulic
            tabStreet[0] = pictureBoxStreetMap1;
            tabStreet[1] = pictureBoxStreetMap2;
            tabStreet[2] = pictureBoxStreetMap3;
            tabStreet[3] = pictureBoxStreetMap4;
            tabStreet[4] = pictureBoxStreetMap5;
            tabStreet[5] = pictureBoxStreetMap6;
            tabStreet[6] = pictureBoxStreetMap7;
            tabStreet[7] = pictureBoxStreetMap8;
            tabStreet[8] = pictureBoxStreetMap9;
            tabStreet[9] = pictureBoxStreetMap10;
            tabStreet[10] = pictureBoxStreetMap11;
            tabStreet[11] = pictureBoxStreetMap12;
            tabStreet[12] = pictureBoxStreetMap13;

            //budynki z konstruktorami, które otrzymują ich cenę, umiejętność podwyższania sukcesów oraz nazwę
            ///Argumenty: cena; boostery: wygląd, bezpieczeństwo, edukacja, komunikacja, ludność
            Building policeStation = new Building(7, 0, 20, 5, 5, 10, "police station");
            Building park = new Building(60, 50, 0, 5, 20, 20, "park");
            Building street = new Building(10, 5, 0, 0, 60, 10, "street");
            Building bank = new Building(42, 5, 20, 5, 10, 30, "bank");
            Building school = new Building(250, 10, 5, 60, 5, 60, "school");
            Building airport = new Building(190, 30, 10, 0, 80, 50, "airport");

            //dodanie budynków do listy
            buildings.Add(policeStation);
            buildings.Add(park);
            buildings.Add(street);
            buildings.Add(bank);
            buildings.Add(school);
            buildings.Add(airport);
           
        }

        ///<summary>
        ///Funkcja pomnażająca pieniądze i zwiększająca ludność zależna od czasu
        ///</summary>
        private void timerMoney_Tick(object sender, EventArgs e)
        {            
            //+1 pieniążek co interwał czasowy
            money++;
            //Wyświetlenie tekstu
            textBoxMoney.Text = money + " $";

            //generowanie wprowadzania się nowych mieszkańców (pojawianie się domów)
            if (peopleRate > 100)
            {
                pictureBoxHouseMap1.Visible = true;
            }                
          
            else if (peopleRate > 400)
                pictureBoxHouseMap2.Visible = true;

            else if (peopleRate > 800)
                pictureBoxHouseMap3.Visible = true;

            else if (peopleRate > 1200)
            {
                pictureBoxHouseMap4.Visible = true;
                communicationRate--; //utrudnienie komunikacji
            }                

            else if (peopleRate > 1500)
            {
                peopleRate -= 5;
                pictureBoxHouseMap5.Visible = true;
                communicationRate -= 5; //utrudnienie komunikacji
            }                

            else if (peopleRate > 1800)
            {
                pictureBoxHouseMap6.Visible = true;
                peopleRate -= 20;
                communicationRate -= 20; //utrudnienie komunikacji
            }
                

            else if (peopleRate > 2200)
            {
                pictureBoxHouseMap7.Visible = true;
                peopleRate -= 40;
                communicationRate -= 30; //utrudnienie komunikacji
            }
                


            //aktualizacja przycisków dla każdego budynku, gdy są odpowiednie warunki
            foreach (Building b in buildings)
            {
                if (b.name.Equals("police station"))
                {
                    //jeśli na mapie jest widoczny obrazek posterunku, przycisk kupienia nieaktywny
                    if (pictureBoxPoliceMap.Visible) buttonPolice.Enabled = false;
                    //jeśli nie stać nas na postreunek, przycisk kupienia nieaktywny
                    if (money < b.price) buttonPolice.Enabled = false;
                    //jeśli stać nas na posterunek, przycisk aktywny
                    if (money >= b.price)
                    {
                        buttonPolice.Enabled = true;
                        if (b.isVisible) buttonPolice.Text = "Ulepsz posterunek";
                    }
                }
                else if ((b.name.Equals("park")))
                {
                    if (pictureBoxParkMap1.Visible) buttonPark.Enabled = false;
                    if (money < b.price) buttonPark.Enabled = false;
                    if (money >= b.price)
                    {
                        buttonPark.Enabled = true;
                        if (b.isVisible) buttonPark.Text = "Ulepsz park";
                    }
                }
                else if ((b.name.Equals("street")))
                {
                    if (pictureBoxStreetMap1.Visible) buttonStreet.Enabled = false;//last
                    if (money < b.price) buttonStreet.Enabled = false;
                    if (money >= b.price && streetIndex < tabStreet.Length) buttonStreet.Enabled = true;
                }
                else if ((b.name.Equals("bank")))
                {
                    if (pictureBoxBankMap.Visible) buttonBank.Enabled = false;
                    if (money < b.price) buttonBank.Enabled = false;
                    if (money >= b.price && bankLevel <= maxBankLevel)
                    {
                        buttonBank.Enabled = true;
                        if (b.isVisible) buttonBank.Text = "Ulepsz bank";
                    }
                }
                else if ((b.name.Equals("school")))
                {
                    if (pictureBoxSchoolMap.Visible) buttonSchool.Enabled = false;
                    if (money < b.price) buttonSchool.Enabled = false;
                    if (money >= b.price)
                    {
                        buttonSchool.Enabled = true;
                        if (b.isVisible) buttonSchool.Text = "Ulepsz szkołę";
                    }
                }
                else if ((b.name.Equals("airport")))
                {
                    if (pictureBoxAirportMap.Visible) buttonAirport.Enabled = false;
                    if (money < b.price) buttonAirport.Enabled = false;
                    if (money >= b.price && !b.isVisible) buttonAirport.Enabled = true;
                    if (b.isVisible) buttonAirport.Text = "Niedostępne";
                }

            }

        }

      
        /// <summary>
        /// Akcje uruchamiane po przyciśnięciu przycisku policji
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
       
        private void buttonPolice_Click(object sender, EventArgs e)
        {
            //wyswietlenie na planszy
            pictureBoxPoliceMap.Visible = true;

            //przycisk asekuracyjnie wyłączamy (może już nie być pieniędzy na ten obiekt)
            buttonPolice.Enabled = false;

            //odejmujemy od puli pieniędzy wydatek
            money -= buildings[0].price;

            //pojawia się label levelu dla tego budynku
            labelPoliceLevel.Visible = true;
            //Kliknięcie przycisku oznacza również zwiększenie levelu policji - zaczynamy od levelu 0
            labelPoliceLevel.Text = "Level" + policeLevel++;

            //ustawiamy (bool) ten budynek na widoczny na planszy
            buildings[0].isVisible = true;

            //Informacja dla użytkownika
            MessageBox.Show("Miasto jest bezpieczniejsze i jeszcze więcej ludzi chce tu mieszkać!");

            //gdy budynek osiągnie odpowiedni poziom, ustawiamy jego lepsze boosty na dany sektor (edukacji, bezpieczeństwa itp.)
            if (policeLevel == 1) buildings[0].setBoosts(0,20,0,0,5);
            if (policeLevel == 2) buildings[0].setBoosts(0, 40, 0, 0, 5);
            if (policeLevel == 3) buildings[0].setBoosts(0, 90, 0, 0, 5);
            if (policeLevel > 3 && policeLevel < 6) buildings[0].setBoosts(0, 150, 0, 0, 10);
            if (policeLevel > 6 && policeLevel < 12) buildings[0].setBoosts(0, 200, 0, 0, 15);
            if (policeLevel > 12 ) buildings[0].setBoosts(5, 250, 0, 0, 20);
        }

        /// <summary>
        /// Akcje uruchamiane po przyciśnięciu przycisku parku
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonPark_Click(object sender, EventArgs e)
        {
            //wyswietlenie na planszy
            pictureBoxParkMap1.Visible = true;
            pictureBoxParkMap2.Visible = true;
            pictureBoxParkMap3.Visible = true;
            pictureBoxParkMap4.Visible = true;

            //przycisk asekuracyjnie wyłączamy (może już nie być pieniędzy na ten obiekt)
            buttonPark.Enabled = false;

            //odejmujemy od puli pieniędzy wydatek
            money -= buildings[1].price;

            //pojawia się label levelu dla tego budynku
            labelParkLevel.Visible = true;
            labelParkLevel.Text = "Level" + parkLevel++;

            //ustawiamy (bool) ten budynek na widoczny na planszy
            buildings[1].isVisible = true;

            //Informacja dla użytkownika
            MessageBox.Show("Miasto jest piękniejsze i ludzie to doceniają!");

            //gdy budynek osiągnie odpowiedni poziom, ustawiamy jego lepsze boosty na dany sektor (edukacji, bezpieczeństwa itp.)
            if (parkLevel == 1) buildings[1].setBoosts(20, 0, 0, 0, 5);
            if (parkLevel == 2) buildings[1].setBoosts(40, 0, 0, 0, 5);
            if (parkLevel == 3) buildings[1].setBoosts(60, 0, 0, 0, 5);
            if (parkLevel > 3 && policeLevel < 6) buildings[1].setBoosts(80, 0, 0, 0, 10);
            if (parkLevel > 6 && policeLevel < 12) buildings[1].setBoosts(100, 0, 0, 0, 15);
            if (parkLevel > 12) buildings[1].setBoosts(200, 0, 0, 0, 20);
        }

        /// <summary>
        /// Akcje uruchamiane po przyciśnięciu przycisku drogi - dodanie kolejnej
        /// </summary>
        int streetIndex = 0;
        private void buttonStreet_Click(object sender, EventArgs e)
        {
            //wyswietlenie na planszy
            tabStreet[streetIndex].Visible = true;

            //przycisk asekuracyjnie wyłączamy (może już nie być pieniędzy na ten obiekt)
            buttonStreet.Enabled = false;

            //odejmujemy od puli pieniędzy wydatek
            money -= buildings[2].price;
              streetIndex++;

            //ustawiamy (bool), że ten budynek jest widoczny na planszy
            buildings[2].isVisible = true;
        }

        /// <summary>
        /// Akcje uruchamiane po przyciśnięciu przycisku banku + negatywne wpływy
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonBank_Click(object sender, EventArgs e)
        {
            //wyswietlenie na planszy
            pictureBoxBankMap.Visible = true;

            //przycisk asekuracyjnie wyłączamy (może już nie być pieniędzy na ten obiekt)
            buttonBank.Enabled = false;

            //odejmujemy od puli pieniędzy wydatek
            money -= buildings[3].price;
                        
            //ustawiamy (bool), że ten budynek jest widoczny na planszy
            labelBankLevel.Visible = true;

            //pojawia się label levelu dla tego budynku
            labelBankLevel.Text = "Level" + bankLevel;
            

            //Informacja dla użytkownika
            MessageBox.Show("Twoje pieniądze pomnażają się szybciej!");

            //gdy mamy więcej niż 20 dolarów, bank zaczyna działać - pomaga nam szybciej zdobywać fundusze
            if (money > 20)
            {
                if (bankLevel == 0) timerMoney.Interval = 600;
                if (bankLevel == 1) timerMoney.Interval = 500;
                if (bankLevel == 2) timerMoney.Interval = 400;
                if (bankLevel == 3) timerMoney.Interval = 250;
                else buttonBank.Enabled = false;
            }

            buildings[3].isVisible = true;

            //-------------Ciekawe wydarzenia-------------------------
            //jeśli bank jest na levelu wyższym, obniża bezpieczeństwo
            if (bankLevel == 1)
            {
                buildings[3].setBoosts(0, -60, 0, 0, 0);
                //Wiadomość dla gracza - raz nie co tik zegara
                MessageBox.Show("Bank rośnie w siłę. Zdarzają się małe napady!");
            }
            else if (bankLevel == 2)
            {
                buildings[3].setBoosts(0, -80, 0, 0, 0);
                //Wiadomość dla gracza zależnie od posiadanego levelu policji, która wpływa na bezpieczeństwo - raz nie co tik zegara
                if (policeLevel < 4 && securityRate < 300) MessageBox.Show("Uważaj, w okolicy banku jest niebezpiecznie! Gdzie jest policja?!");
                else MessageBox.Show("Bezpieczeństwo nieco spada! Upewnij się, że ludzie pozostaną bezpieczni!");
            }
            else if (bankLevel == 2)
            {
                buildings[3].setBoosts(0, -130, 0, 0, 0);
            }

                //podwyższenie levelu banku na końcu
                bankLevel++;
        }

        /// <summary>
        /// Akcje uruchamiane po przyciśnięciu przycisku szkoły
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSchool_Click(object sender, EventArgs e)
        {
            //wyswietlenie na planszy
            pictureBoxSchoolMap.Visible = true;

            //przycisk asekuracyjnie wyłączamy (może już nie być pieniędzy na ten obiekt)
            buttonSchool.Enabled = false;

            //odejmujemy od puli pieniędzy wydatek
            money -= buildings[4].price;

            //pojawia się label levelu dla tego budynku
            labelSchoolLevel.Visible = true;
            labelSchoolLevel.Text = "Level" + schoolLevel++;

            //ustawiamy (bool), że ten budynek jest widoczny na planszy
            buildings[4].isVisible = true;

            //Informacja dla użytkownika
            MessageBox.Show("Edukacja rośnie w siłę. Ludzie doceniają piękną szkołę!");

            //gdy budynek osiągnie odpowiedni poziom, ustawiamy jego lepsze boosty na dany sektor (edukacji, bezpieczeństwa itp.)
            if (schoolLevel == 1) buildings[4].setBoosts(0, 0, 20, 0, 5);
            if (schoolLevel == 2) buildings[4].setBoosts(5, 0, 40, 0, 5);
            if (schoolLevel == 3) buildings[4].setBoosts(10, 5, 60, 0, 5);
            if (schoolLevel > 3 && policeLevel < 6) buildings[4].setBoosts(30, 5, 100, 0, 15);
            if (schoolLevel > 6 && policeLevel < 12) buildings[4].setBoosts(50, 5, 150, 0, 30);
            if (schoolLevel > 12) buildings[4].setBoosts(70, 10, 100, 5, 60);
        }

        /// <summary>
        /// Akcje uruchamiane po przyciśnięciu przycisku lotniska
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonAirport_Click(object sender, EventArgs e)
        {
            //wyswietlenie na planszy
            pictureBoxAirportMap.Visible = true;

            //przycisk asekuracyjnie wyłączamy (może już nie być pieniędzy na ten obiekt)
            buttonAirport.Enabled = false;

            //odejmujemy od puli pieniędzy wydatek
            money -= buildings[5].price;
            buildings[5].isVisible = true;

            //Informacja dla użytkownika
            MessageBox.Show("Twoje miasto ma najlepszą komunikację w regionie!");

            //lotnisko nie ma poziomów, samo jego dodanie sprawia, że boost będzie stały
            //po wybudowaniu jednego lotniska, nie można zbudować kolejnego
            buildings[5].setBoosts(0, 5, 0, 100, 0);
        }

        /// <summary>
        /// Timer wpływający na podwyższanie sektorów życia w mieście
        /// </summary>
        int time = 0;
       private void timerBoost_Tick(object sender, EventArgs e)
        {
            //Zwiększanie licznika, by wiedzieć, ile czasu upłynęło od początku gry
            time++;

            //aktualizacja sektorów     
            foreach(Building p in buildings)
            {
                //tylko dla budynków będących na mapie
                if(p.isVisible)
                {
                    //aktualizacja rate różnych dziedzin
                    p.Update();

                    //wyświetlenie aktualizacji w textboxach
                    textBoxAppearance.Text = appearanceRate.ToString();
                    textBoxSecurity.Text = securityRate.ToString();
                    textBoxEducation.Text = educationRate.ToString();
                    textBoxCommunication.Text = communicationRate.ToString();
                    textBoxPopulation.Text = peopleRate.ToString();
                }
            }
            
            //----------------Ciekawe wydarzenia utrudniające grę------------------          
            if (time > 8 && !wasApocalipse)
            {
                MessageBox.Show("O nie! Przyszła wichura i zniszczyła Lokalną Kasę Oszczędnościową!");
                money -= 100;
                wasApocalipse = true;
            }

        }


        /// <summary>
        /// Zapisywanie stanu dataGridViewInfo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSave_Click(object sender, EventArgs e)
        {
            
            int n = dataGridViewInfo.Rows.Add();
            dataGridViewInfo.Rows[n].Cells[0].Value = textBoxAppearance.Text;
            dataGridViewInfo.Rows[n].Cells[1].Value = textBoxSecurity.Text;
            dataGridViewInfo.Rows[n].Cells[2].Value = textBoxEducation.Text;
            dataGridViewInfo.Rows[n].Cells[3].Value = textBoxCommunication.Text;
            dataGridViewInfo.Rows[n].Cells[4].Value = textBoxPopulation.Text;
            dataGridViewInfo.Rows[n].Cells[5].Value = textBoxMoney.Text;
        }

    }
}
